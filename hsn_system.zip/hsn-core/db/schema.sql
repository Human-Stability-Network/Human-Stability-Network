CREATE TABLE contributors(id UUID, name TEXT);
