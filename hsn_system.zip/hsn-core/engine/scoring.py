def stability_score(x): return 0
